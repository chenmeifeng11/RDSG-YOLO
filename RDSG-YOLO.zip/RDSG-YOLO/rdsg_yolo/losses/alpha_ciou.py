"""Alpha-CIoU bounding box regression loss."""

import math
import torch
import torch.nn as nn


def alpha_ciou_loss(box1, box2, xywh=False, kappa=3.0, eps=1e-7):
    """Compute element-wise Alpha-CIoU loss between paired bounding boxes.

    Args:
        box1: Predicted boxes of shape (..., 4) in xyxy (default) or xywh.
        box2: Ground-truth boxes of shape (..., 4) in the same format.
        xywh: If True, inputs are (cx, cy, w, h); otherwise (x1, y1, x2, y2).
        kappa: Power exponent (kappa=1 reduces to standard CIoU; default 3.0).
        eps: Numerical stability epsilon.
    Returns:
        Tensor of per-pair Alpha-CIoU losses with shape (...).
    """
    if xywh:
        x1, y1, w1, h1 = box1.unbind(-1)
        x2, y2, w2, h2 = box2.unbind(-1)
        b1_x1, b1_x2 = x1 - w1 * 0.5, x1 + w1 * 0.5
        b1_y1, b1_y2 = y1 - h1 * 0.5, y1 + h1 * 0.5
        b2_x1, b2_x2 = x2 - w2 * 0.5, x2 + w2 * 0.5
        b2_y1, b2_y2 = y2 - h2 * 0.5, y2 + h2 * 0.5
    else:
        b1_x1, b1_y1, b1_x2, b1_y2 = box1.unbind(-1)
        b2_x1, b2_y1, b2_x2, b2_y2 = box2.unbind(-1)
        w1 = (b1_x2 - b1_x1).clamp(min=eps)
        h1 = (b1_y2 - b1_y1).clamp(min=eps)
        w2 = (b2_x2 - b2_x1).clamp(min=eps)
        h2 = (b2_y2 - b2_y1).clamp(min=eps)

    inter_w = (torch.minimum(b1_x2, b2_x2) - torch.maximum(b1_x1, b2_x1)).clamp(min=0.0)
    inter_h = (torch.minimum(b1_y2, b2_y2) - torch.maximum(b1_y1, b2_y1)).clamp(min=0.0)
    inter = inter_w * inter_h

    union = w1 * h1 + w2 * h2 - inter + eps
    iou = (inter / union).clamp(min=eps, max=1.0)

    # Smallest enclosing box diagonal squared d^2
    cw = torch.maximum(b1_x2, b2_x2) - torch.minimum(b1_x1, b2_x1)
    ch = torch.maximum(b1_y2, b2_y2) - torch.minimum(b1_y1, b2_y1)
    c2 = cw.pow(2) + ch.pow(2) + eps

    # Center distance squared rho^2(b, b^gt)
    rho2 = (
        ((b2_x1 + b2_x2 - b1_x1 - b1_x2) ** 2 + (b2_y1 + b2_y2 - b1_y1 - b1_y2) ** 2) * 0.25
    )

    # Aspect-ratio consistency term v and trade-off weight beta
    v = (4.0 / (math.pi ** 2)) * torch.pow(
        torch.atan(w2 / (h2 + eps)) - torch.atan(w1 / (h1 + eps)), 2
    )
    with torch.no_grad():
        beta = v / (1.0 - iou + v + eps)

    dist_term = (rho2 / c2).clamp(min=eps)
    aspect_term = (beta * v).clamp(min=0.0)

    if kappa == 1.0:
        loss = 1.0 - iou + dist_term + aspect_term
    else:
        loss = 1.0 - iou.pow(kappa) + dist_term.pow(kappa) + (aspect_term + eps).pow(kappa)
    return loss


class AlphaCIoULoss(nn.Module):
    """Module wrapper around alpha_ciou_loss."""

    def __init__(self, kappa=3.0, xywh=False, reduction="mean", eps=1e-7):
        super().__init__()
        self.kappa = float(kappa)
        self.xywh = xywh
        self.reduction = reduction
        self.eps = eps

    def forward(self, pred_boxes, target_boxes, weight=None):
        loss = alpha_ciou_loss(pred_boxes, target_boxes, xywh=self.xywh, kappa=self.kappa, eps=self.eps)
        if weight is not None:
            loss = loss * weight
        if self.reduction == "mean":
            return loss.mean()
        if self.reduction == "sum":
            return loss.sum()
        return loss


def patch_ultralytics_alpha_ciou(kappa=3.0):
    """Replace Ultralytics bbox_iou CIoU scoring with Alpha-CIoU during training.

    Ultralytics BboxLoss computes `loss_iou = (1.0 - iou)`. Returning
    `1.0 - alpha_ciou_loss` preserves full compatibility with BboxLoss while
    applying exact Alpha-CIoU regression gradients.
    """
    import ultralytics.utils.loss as ul_loss

    orig_bbox_iou = ul_loss.bbox_iou

    def _alpha_bbox_iou(box1, box2, xywh=True, GIoU=False, DIoU=False, CIoU=False, eps=1e-7):
        if CIoU and not GIoU and not DIoU:
            loss = alpha_ciou_loss(box1, box2, xywh=xywh, kappa=kappa, eps=eps)
            return (1.0 - loss).unsqueeze(-1)
        return orig_bbox_iou(box1, box2, xywh=xywh, GIoU=GIoU, DIoU=DIoU, CIoU=CIoU, eps=eps)

    ul_loss.bbox_iou = _alpha_bbox_iou

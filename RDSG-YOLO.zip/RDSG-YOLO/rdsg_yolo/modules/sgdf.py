"""Structure-Guided Detail Fusion (SGDF) module."""

import torch
import torch.nn as nn
import torch.nn.functional as F


class SGDF(nn.Module):
    """Structure-Guided Detail Fusion (SGDF) for cross-scale top-down fusion.

    Integrates adaptive low-pass upsampling (ALPF), adaptive high-pass detail
    enhancement (AHPF), and local-similarity resampling under a shared
    protection gate driven by backbone difference maps E^l.
    """

    def __init__(self, c_shallow, c_deep, c_diff=None, c_compress=24, lp_k=5, hp_k=3):
        super().__init__()
        self.c_shallow = c_shallow
        self.c_deep = c_deep
        self.c_diff = c_diff if c_diff is not None else c_shallow // 4
        self.c_compress = c_compress
        self.lp_k = lp_k
        self.hp_k = hp_k

        # Channel alignment and compression
        self.align_deep = nn.Conv2d(c_deep, c_shallow, kernel_size=1, bias=False)
        self.comp_x = nn.Conv2d(c_shallow, c_compress, kernel_size=1, bias=False)
        self.comp_y = nn.Conv2d(c_shallow, c_compress, kernel_size=1, bias=False)

        # Initial ALPF and AHPF generators driven by X_c^l (conv -> pixel_unshuffle -> 4*K^2)
        self.ini_alpf = nn.Conv2d(c_compress, lp_k * lp_k, kernel_size=3, padding=1)
        self.ini_ahpf = nn.Conv2d(c_compress, hp_k * hp_k, kernel_size=3, padding=1)

        # Shared structural protection gate
        self.phi_e = nn.Conv2d(self.c_diff, c_compress, kernel_size=1, bias=False)
        self.gate_conv = nn.Conv2d(c_compress * 3, 1, kernel_size=3, padding=1, bias=True)
        self.theta = nn.Parameter(torch.zeros(1))

        # Final ALPF, AHPF, and offset generators driven by Z^l
        self.alpf_gen = nn.Conv2d(c_compress, lp_k * lp_k, kernel_size=3, padding=1)
        self.ahpf_gen = nn.Conv2d(c_compress, hp_k * hp_k, kernel_size=3, padding=1)
        self.offset_dir = nn.Conv2d(c_compress + 8, 2, kernel_size=3, padding=1)
        self.offset_amp = nn.Conv2d(c_compress + 8, 2, kernel_size=3, padding=1)

        # Identity kernels K_0 (5x5) and I (3x3)
        k0_lp = torch.zeros(1, 1, lp_k * lp_k, 1, 1)
        k0_lp[0, 0, (lp_k * lp_k) // 2, 0, 0] = 1.0
        self.register_buffer("k0_lp", k0_lp)

        k0_hp = torch.zeros(1, hp_k * hp_k, 1, 1)
        k0_hp[0, (hp_k * hp_k) // 2, 0, 0] = 1.0
        self.register_buffer("k0_hp", k0_hp)

        self.last_gate = None

    def _lowpass_upsample(self, feat, kernels):
        """Apply 2x sub-pixel content-dependent lp_k x lp_k low-pass upsampling.

        Args:
            feat: (B, C, H, W) deep feature map.
            kernels: (B, 4, K^2, H, W) normalized low-pass kernels.
        Returns:
            (B, C, 2H, 2W) upsampled feature map.
        """
        b, c, h, w = feat.shape
        k2 = self.lp_k * self.lp_k
        pad = self.lp_k // 2
        unf = F.unfold(feat, kernel_size=self.lp_k, padding=pad).view(b, c, k2, h, w)
        # (B, C, 4, H, W)
        out = torch.einsum("bckhw,bskhw->bcshw", unf, kernels)
        out = out.reshape(b, c * 4, h, w)
        return F.pixel_shuffle(out, 2)

    def _apply_highpass(self, feat, k_hp):
        """Apply spatial hp_k x hp_k high-pass kernel to feat."""
        b, c, h, w = feat.shape
        k2 = self.hp_k * self.hp_k
        pad = self.hp_k // 2
        unf = F.unfold(feat, kernel_size=self.hp_k, padding=pad).view(b, c, k2, h, w)
        return (unf * k_hp.unsqueeze(1)).sum(dim=2)

    @staticmethod
    def _local_cosine_similarity(z):
        """Compute cosine similarity between z and its 8 immediate neighbors."""
        b, c, h, w = z.shape
        z_norm = F.normalize(z, p=2, dim=1, eps=1e-6)
        z_pad = F.pad(z_norm, (1, 1, 1, 1), mode="replicate")
        sims = []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                if dy == 0 and dx == 0:
                    continue
                nbr = z_pad[:, :, 1 + dy : 1 + dy + h, 1 + dx : 1 + dx + w]
                sims.append((z_norm * nbr).sum(dim=1, keepdim=True))
        return torch.cat(sims, dim=1)  # (B, 8, H, W)

    @staticmethod
    def _bilinear_resample(feat, offset_px):
        """Resample feat on regular grid O_0 + offset_px (in pixel units)."""
        b, _, h, w = feat.shape
        device, dtype = feat.device, feat.dtype
        gy, gx = torch.meshgrid(
            torch.linspace(-1.0, 1.0, h, device=device, dtype=dtype),
            torch.linspace(-1.0, 1.0, w, device=device, dtype=dtype),
            indexing="ij",
        )
        base_grid = torch.stack((gx, gy), dim=-1).unsqueeze(0).expand(b, -1, -1, -1)
        dx = offset_px[:, 0, :, :] * (2.0 / max(w - 1, 1))
        dy = offset_px[:, 1, :, :] * (2.0 / max(h - 1, 1))
        grid = base_grid + torch.stack((dx, dy), dim=-1)
        return F.grid_sample(feat, grid, mode="bilinear", padding_mode="border", align_corners=True)

    def forward(self, x_shallow, y_deep=None, diff_map=None):
        """Forward pass supporting either (x, y, e) arguments or tuple/list input."""
        if isinstance(x_shallow, (list, tuple)):
            if len(x_shallow) == 3:
                x_shallow, y_deep, diff_map = x_shallow
            else:
                x_shallow, y_deep = x_shallow

        b, _, h2, w2 = x_shallow.shape
        _, _, h, w = y_deep.shape
        k2 = self.lp_k * self.lp_k

        # Align deep channels and compress to 24 channels
        y_aligned = self.align_deep(y_deep)
        x_c = self.comp_x(x_shallow)
        y_c = self.comp_y(y_aligned)

        # Initial fused representation Z^l
        k_lp_ini_raw = F.pixel_unshuffle(self.ini_alpf(x_c), 2).view(b, k2, 4, h, w).transpose(1, 2)
        k_lp_ini = F.softmax(k_lp_ini_raw, dim=2)
        y_c_up_ini = self._lowpass_upsample(y_c, k_lp_ini)

        k_hp_ini = self.k0_hp - F.softmax(self.ini_ahpf(x_c), dim=1)
        x_c_hp_ini = self._apply_highpass(x_c, k_hp_ini)
        z = y_c_up_ini + x_c + x_c_hp_ini

        # Shared protection gate a^l = eta * g^l
        y_c_nn = F.interpolate(y_c, size=(h2, w2), mode="nearest")
        if diff_map is None:
            e_proj = torch.zeros_like(x_c)
        else:
            e_proj = self.phi_e(diff_map)
        g = torch.sigmoid(self.gate_conv(torch.cat([x_c, y_c_nn, e_proj], dim=1)))
        eta = torch.sigmoid(self.theta)
        a = eta * g
        self.last_gate = a

        # Protected ALPF upsampling
        k_lp_raw = F.pixel_unshuffle(self.alpf_gen(z), 2).view(b, k2, 4, h, w).transpose(1, 2)
        k_lp = F.softmax(k_lp_raw, dim=2)
        a_sub = F.pixel_unshuffle(a, 2).unsqueeze(2)  # (B, 4, 1, H, W)
        k_lp_prot = (1.0 - a_sub) * k_lp + a_sub * self.k0_lp
        y_up = self._lowpass_upsample(y_aligned, k_lp_prot)

        # Protected local-similarity resampling
        sim = self._local_cosine_similarity(z)
        off_in = torch.cat([z, sim], dim=1)
        raw_delta = self.offset_dir(off_in) * torch.sigmoid(self.offset_amp(off_in))
        delta_prot = (1.0 - a) * raw_delta
        y_resamp = self._bilinear_resample(y_up, delta_prot)

        # AHPF edge enhancement on shallow feature X^l
        k_hat_lp = F.softmax(self.ahpf_gen(z), dim=1)
        k_hp = self.k0_hp - k_hat_lp
        x_tilde = x_shallow + self._apply_highpass(x_shallow, k_hp)

        return y_resamp + x_tilde

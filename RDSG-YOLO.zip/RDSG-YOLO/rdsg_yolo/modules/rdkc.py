"""Reference-Difference Kernel Convolution (RDKC) and C2f-RDKC blocks."""

import torch
import torch.nn as nn
import torch.nn.functional as F

from rdsg_yolo.modules.common import Conv


class RDKC(nn.Module):
    """Reference-Difference Kernel Convolution (RDKC).

    Combines a large-kernel contextual base-kernel pathway with a parallel
    multi-directional symmetric reference-difference pathway to modulate
    grouped 3x3 local aggregation weights.
    """

    DIRECTIONS = ((1, 0), (0, 1), (1, 1), (1, -1))

    def __init__(self, channels, group_size=8, radii=(2, 4), eps=1e-6):
        super().__init__()
        if channels % group_size != 0:
            raise ValueError(f"channels ({channels}) must be divisible by group_size ({group_size})")
        self.channels = channels
        self.group_size = group_size
        self.groups = channels // group_size
        self.mid_c = channels // 2
        self.radii = tuple(radii)
        self.num_candidates = len(self.DIRECTIONS) * len(self.radii)
        self.eps = eps

        # Contextual base-kernel generator Phi_b
        self.base_gen = nn.Sequential(
            nn.Conv2d(channels, self.mid_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(self.mid_c),
            nn.SiLU(inplace=True),
            nn.Conv2d(self.mid_c, self.mid_c, kernel_size=7, padding=3, groups=self.mid_c, bias=False),
            nn.BatchNorm2d(self.mid_c),
            nn.SiLU(inplace=True),
            nn.Conv2d(self.mid_c, 9 * self.groups, kernel_size=1, bias=True),
        )

        # Reference-difference pathway
        self.phi_u = nn.Sequential(
            nn.Conv2d(channels, self.mid_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(self.mid_c),
            nn.SiLU(inplace=True),
        )
        self.phi_s = nn.Conv2d(self.num_candidates * self.mid_c, self.num_candidates, kernel_size=1, bias=True)
        self.phi_delta = nn.Conv2d(2 * self.mid_c, 9 * self.groups, kernel_size=1, bias=True)

        self.gamma = nn.Parameter(torch.ones(1))
        self.bn = nn.BatchNorm2d(channels)
        self.last_diff_map = None

    def _compute_reference_candidates(self, u):
        _, _, h, w = u.shape
        candidates = []
        for r in self.radii:
            u_pad = F.pad(u, (r, r, r, r), mode="replicate")
            for dx, dy in self.DIRECTIONS:
                y_pos = r + dy * r
                x_pos = r + dx * r
                y_neg = r - dy * r
                x_neg = r - dx * r
                v_pos = u_pad[:, :, y_pos : y_pos + h, x_pos : x_pos + w]
                v_neg = u_pad[:, :, y_neg : y_neg + h, x_neg : x_neg + w]
                candidates.append(0.5 * (v_pos + v_neg))
        return candidates

    def forward(self, x, return_diff=False):
        b, c, h, w = x.shape

        # Base kernel K_b: (B, G, 9, H, W)
        k_base = self.base_gen(x).view(b, self.groups, 9, h, w)

        # Symmetric multi-directional reference R and difference E
        u = self.phi_u(x)
        candidates = self._compute_reference_candidates(u)
        v_cat = torch.cat(candidates, dim=1)
        alpha = F.softmax(self.phi_s(v_cat), dim=1)
        v_stack = torch.stack(candidates, dim=1)  # (B, 8, C/2, H, W)
        ref = (alpha.unsqueeze(2) * v_stack).sum(dim=1)
        diff = u - ref
        self.last_diff_map = diff

        # Stabilized difference kernel K_delta: zero-mean + L1 normalization
        raw_a = self.phi_delta(torch.cat([ref, diff], dim=1)).view(b, self.groups, 9, h, w)
        centered = raw_a - raw_a.mean(dim=2, keepdim=True)
        k_delta = centered / (centered.abs().sum(dim=2, keepdim=True) + self.eps)

        # Combined dynamic kernel K = K_b + gamma * K_delta
        k_total = k_base + self.gamma * k_delta

        # Grouped 3x3 dynamic local aggregation
        x_unf = F.unfold(x, kernel_size=3, padding=1).view(b, self.groups, self.group_size, 9, h, w)
        agg = (x_unf * k_total.unsqueeze(2)).sum(dim=3).reshape(b, c, h, w)
        out = x + self.bn(agg)

        if return_diff:
            return out, diff
        return out


class C2fRDKC(nn.Module):
    """C2f stage with inner bottlenecks replaced by RDKC units.

    Exports the difference map E from the final RDKC unit for downstream
    structure-guided cross-scale fusion in SGDF.
    """

    def __init__(self, c1, c2, n=2, group_size=8, radii=(2, 4), e=0.5):
        super().__init__()
        self.c = int(c2 * e)
        self.cv1 = Conv(c1, 2 * self.c, 1, 1)
        self.cv2 = Conv((2 + n) * self.c, c2, 1)
        self.m = nn.ModuleList(
            RDKC(self.c, group_size=group_size, radii=radii) for _ in range(n)
        )
        self.last_diff_map = None

    def forward(self, x, return_diff=False):
        y = list(self.cv1(x).chunk(2, 1))
        diff = None
        for unit in self.m:
            feat, diff = unit(y[-1], return_diff=True)
            y.append(feat)
        self.last_diff_map = diff
        out = self.cv2(torch.cat(y, 1))
        if return_diff:
            return out, diff
        return out

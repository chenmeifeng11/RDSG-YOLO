"""Bounding box localization precision metrics (median e_c and median 1 - IoU)."""

import numpy as np


def box_iou_matrix(boxes1, boxes2):
    """Compute pairwise IoU matrix between boxes1 (N, 4) and boxes2 (M, 4) in xyxy."""
    if len(boxes1) == 0 or len(boxes2) == 0:
        return np.zeros((len(boxes1), len(boxes2)), dtype=np.float64)
    b1 = np.asarray(boxes1, dtype=np.float64)
    b2 = np.asarray(boxes2, dtype=np.float64)

    x1 = np.maximum(b1[:, None, 0], b2[None, :, 0])
    y1 = np.maximum(b1[:, None, 1], b2[None, :, 1])
    x2 = np.minimum(b1[:, None, 2], b2[None, :, 2])
    y2 = np.minimum(b1[:, None, 3], b2[None, :, 3])

    inter = np.maximum(0.0, x2 - x1) * np.maximum(0.0, y2 - y1)
    area1 = np.maximum(0.0, b1[:, 2] - b1[:, 0]) * np.maximum(0.0, b1[:, 3] - b1[:, 1])
    area2 = np.maximum(0.0, b2[:, 2] - b2[:, 0]) * np.maximum(0.0, b2[:, 3] - b2[:, 1])
    union = area1[:, None] + area2[None, :] - inter + 1e-9
    return inter / union


def compute_localization_errors(pred_boxes, pred_scores, gt_boxes, conf_thr=0.25, iou_thr=0.50):
    """Match predicted boxes to ground-truth boxes and compute median e_c and 1 - IoU (%).

    Args:
        pred_boxes: List of per-image arrays (N_i, 4) in xyxy pixels.
        pred_scores: List of per-image confidence arrays (N_i,).
        gt_boxes: List of per-image ground-truth arrays (M_i, 4) in xyxy pixels.
        conf_thr: Confidence threshold (default 0.25).
        iou_thr: Matching IoU threshold (default 0.50).
    Returns:
        dict with keys 'median_ec_pct', 'median_1_minus_iou_pct', 'num_matched'.
    """
    ec_list = []
    ov_list = []

    for p_box, p_scr, g_box in zip(pred_boxes, pred_scores, gt_boxes):
        p_box = np.asarray(p_box, dtype=np.float64).reshape(-1, 4)
        p_scr = np.asarray(p_scr, dtype=np.float64).reshape(-1)
        g_box = np.asarray(g_box, dtype=np.float64).reshape(-1, 4)

        keep = p_scr >= conf_thr
        p_box, p_scr = p_box[keep], p_scr[keep]
        if len(p_box) == 0 or len(g_box) == 0:
            continue

        order = np.argsort(-p_scr)
        p_box = p_box[order]
        iou_mat = box_iou_matrix(p_box, g_box)
        matched_gt = set()

        for pi in range(len(p_box)):
            best_gi = int(np.argmax(iou_mat[pi]))
            best_iou = float(iou_mat[pi, best_gi])
            if best_iou >= iou_thr and best_gi not in matched_gt:
                matched_gt.add(best_gi)
                pb = p_box[pi]
                gb = g_box[best_gi]
                pcx, pcy = 0.5 * (pb[0] + pb[2]), 0.5 * (pb[1] + pb[3])
                gcx, gcy = 0.5 * (gb[0] + gb[2]), 0.5 * (gb[1] + gb[3])
                d_gt = np.hypot(gb[2] - gb[0], gb[3] - gb[1]) + 1e-9
                ec = np.hypot(pcx - gcx, pcy - gcy) / d_gt
                ec_list.append(ec * 100.0)
                ov_list.append((1.0 - best_iou) * 100.0)

    if not ec_list:
        return {"median_ec_pct": float("nan"), "median_1_minus_iou_pct": float("nan"), "num_matched": 0}

    return {
        "median_ec_pct": float(np.median(ec_list)),
        "median_1_minus_iou_pct": float(np.median(ov_list)),
        "num_matched": len(ec_list),
    }

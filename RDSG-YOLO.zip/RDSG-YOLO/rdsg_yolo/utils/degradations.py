"""Progressive image degradation transforms for robustness evaluation."""

import cv2
import numpy as np


DEGRADATION_PRESETS = {
    "blur": [0.6, 1.2, 1.8],
    "brightness": [0.8, 0.6, 0.4],
    "noise": [0.01, 0.03, 0.05],
    "jpeg": [90, 60, 30],
}


def apply_gaussian_blur(img_bgr, sigma):
    """Apply isotropic Gaussian blur with standard deviation sigma (px)."""
    if sigma <= 0:
        return img_bgr.copy()
    ksize = int(2 * round(3 * sigma) + 1)
    return cv2.GaussianBlur(img_bgr, (ksize, ksize), sigmaX=sigma, sigmaY=sigma)


def apply_brightness(img_bgr, factor):
    """Scale pixel intensity uniformly by brightness factor in (0, 1]."""
    out = img_bgr.astype(np.float32) * float(factor)
    return np.clip(out, 0, 255).astype(np.uint8)


def apply_gaussian_noise(img_bgr, sigma_ratio, seed=42):
    """Add zero-mean Gaussian noise with std = sigma_ratio * 255."""
    rng = np.random.default_rng(seed)
    noise = rng.normal(0.0, float(sigma_ratio) * 255.0, size=img_bgr.shape)
    out = img_bgr.astype(np.float32) + noise
    return np.clip(out, 0, 255).astype(np.uint8)


def apply_jpeg_compression(img_bgr, quality):
    """Encode and decode image at specified JPEG quality factor."""
    ok, buf = cv2.imencode(".jpg", img_bgr, [int(cv2.IMWRITE_JPEG_QUALITY), int(quality)])
    if not ok:
        raise RuntimeError(f"JPEG encoding failed at quality={quality}")
    return cv2.imdecode(buf, cv2.IMREAD_COLOR)


def apply_degradation(img_bgr, mode, level, seed=42):
    if mode == "blur":
        return apply_gaussian_blur(img_bgr, level)
    if mode == "brightness":
        return apply_brightness(img_bgr, level)
    if mode == "noise":
        return apply_gaussian_noise(img_bgr, level, seed=seed)
    if mode == "jpeg":
        return apply_jpeg_compression(img_bgr, level)
    raise ValueError(f"Unknown degradation mode: {mode}")

"""Standalone PyTorch implementation of the RDSG-YOLO detector (YOLOv8s scale)."""

import torch
import torch.nn as nn

from rdsg_yolo.modules.common import Conv, C2f, SPPF, Detect
from rdsg_yolo.modules.rdkc import C2fRDKC
from rdsg_yolo.modules.sgdf import SGDF


class RDSGYOLO(nn.Module):
    """RDSG-YOLO built upon YOLOv8s with C2f-RDKC at P3/P4 and SGDF in the top-down neck."""

    def __init__(self, nc=2, reg_max=16, c_compress=24):
        super().__init__()
        self.nc = nc

        # Backbone (YOLOv8s channel widths: 32, 64, 128, 256, 512)
        self.stem = Conv(3, 32, k=3, s=2)               # P1/2 (320)
        self.stage2_conv = Conv(32, 64, k=3, s=2)       # P2/4 (160)
        self.stage2_c2f = C2f(64, 64, n=1, shortcut=True)

        self.stage3_conv = Conv(64, 128, k=3, s=2)      # P3/8 (80)
        self.stage3_rdkc = C2fRDKC(128, 128, n=2)       # 2 RDKC units on 64 ch; exports E^3 (32 ch)

        self.stage4_conv = Conv(128, 256, k=3, s=2)     # P4/16 (40)
        self.stage4_rdkc = C2fRDKC(256, 256, n=2)       # 2 RDKC units on 128 ch; exports E^4 (64 ch)

        self.stage5_conv = Conv(256, 512, k=3, s=2)     # P5/32 (20)
        self.stage5_c2f = C2f(512, 512, n=1, shortcut=True)
        self.sppf = SPPF(512, 512, k=5)

        # Top-down neck with SGDF (channel-aligned addition)
        self.sgdf_p4 = SGDF(c_shallow=256, c_deep=512, c_diff=64, c_compress=c_compress)
        self.td_c2f_p4 = C2f(256, 256, n=1, shortcut=False)

        self.sgdf_p3 = SGDF(c_shallow=128, c_deep=256, c_diff=32, c_compress=c_compress)
        self.td_c2f_p3 = C2f(128, 128, n=1, shortcut=False)

        # Bottom-up PAN neck (unchanged from YOLOv8s)
        self.bu_down_p4 = Conv(128, 128, k=3, s=2)
        self.bu_c2f_p4 = C2f(128 + 256, 256, n=1, shortcut=False)

        self.bu_down_p5 = Conv(256, 256, k=3, s=2)
        self.bu_c2f_p5 = C2f(256 + 512, 512, n=1, shortcut=False)

        # Decoupled detection head
        self.detect = Detect(nc=nc, ch=(128, 256, 512), reg_max=reg_max)

    def forward_features(self, x):
        """Run backbone and neck, returning multi-scale features and intermediate maps."""
        x = self.stem(x)
        x = self.stage2_c2f(self.stage2_conv(x))

        p3_raw, e3 = self.stage3_rdkc(self.stage3_conv(x), return_diff=True)
        p4_raw, e4 = self.stage4_rdkc(self.stage4_conv(p3_raw), return_diff=True)
        p5 = self.sppf(self.stage5_c2f(self.stage5_conv(p4_raw)))

        # Top-down SGDF fusion
        p4_td = self.td_c2f_p4(self.sgdf_p4(p4_raw, p5, e4))
        n3 = self.td_c2f_p3(self.sgdf_p3(p3_raw, p4_td, e3))

        # Bottom-up PAN fusion
        n4 = self.bu_c2f_p4(torch.cat([self.bu_down_p4(n3), p4_td], dim=1))
        n5 = self.bu_c2f_p5(torch.cat([self.bu_down_p5(n4), p5], dim=1))

        intermediates = {
            "E3": e3,
            "E4": e4,
            "a3": self.sgdf_p3.last_gate,
            "a4": self.sgdf_p4.last_gate,
        }
        return [n3, n4, n5], intermediates

    def forward(self, x, return_intermediates=False):
        feats, intermediates = self.forward_features(x)
        preds = self.detect(feats)
        if return_intermediates:
            return preds, intermediates
        return preds

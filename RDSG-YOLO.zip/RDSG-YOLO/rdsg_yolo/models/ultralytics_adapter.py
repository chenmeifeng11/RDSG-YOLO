"""Ultralytics integration helpers for registering C2fRDKC and SGDF."""

import torch.nn as nn

from rdsg_yolo.modules.rdkc import C2fRDKC as _BaseC2fRDKC
from rdsg_yolo.modules.sgdf import SGDF as _BaseSGDF

# Shared cache holding the latest backbone difference maps E^l indexed by spatial width
_DIFF_CACHE = {}


class UltralyticsC2fRDKC(_BaseC2fRDKC):
    """Ultralytics-compatible C2fRDKC wrapper caching E^l for downstream SGDF nodes."""

    def forward(self, x):
        out, diff = super().forward(x, return_diff=True)
        _DIFF_CACHE[(diff.shape[-2], diff.shape[-1])] = diff
        return out


class UltralyticsSGDF(_BaseSGDF):
    """Ultralytics-compatible SGDF wrapper consuming [x_shallow, y_deep] and cached E^l."""

    def __init__(self, c_shallow, c_deep, c_out=None):
        super().__init__(c_shallow=c_shallow, c_deep=c_deep)

    def forward(self, inputs):
        x_shallow, y_deep = inputs[0], inputs[1]
        diff = _DIFF_CACHE.get((x_shallow.shape[-2], x_shallow.shape[-1]), None)
        return super().forward(x_shallow, y_deep, diff)


def register_rdsg_modules():
    """Register C2fRDKC and SGDF into Ultralytics module and parser namespaces."""
    import ultralytics.nn.modules as ul_modules
    import ultralytics.nn.tasks as ul_tasks

    setattr(ul_modules, "C2fRDKC", UltralyticsC2fRDKC)
    setattr(ul_modules, "SGDF", UltralyticsSGDF)
    setattr(ul_tasks, "C2fRDKC", UltralyticsC2fRDKC)
    setattr(ul_tasks, "SGDF", UltralyticsSGDF)

    orig_parse = ul_tasks.parse_model

    def _patched_parse_model(d, ch, verbose=True):
        """Ensure SGDF receives (c_shallow, c_deep) channels cleanly from Ultralytics YAML."""
        # Standard parse_model handles single-input modules; pre-patch SGDF construction
        return orig_parse(d, ch, verbose=verbose)

    # Allow Ultralytics parse_model to instantiate SGDF from [from_shallow, from_deep]
    if not getattr(ul_tasks, "_rdsg_patched", False):
        class _SGDFAdapter(UltralyticsSGDF):
            def __init__(self, c1, c2=None):
                if isinstance(c1, (list, tuple)):
                    c_shallow, c_deep = c1[0], c1[1]
                else:
                    c_shallow, c_deep = c1, c2
                super().__init__(c_shallow=c_shallow, c_deep=c_deep)

        setattr(ul_modules, "SGDF", _SGDFAdapter)
        setattr(ul_tasks, "SGDF", _SGDFAdapter)
        ul_tasks._rdsg_patched = True

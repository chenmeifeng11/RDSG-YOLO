"""Evaluate model robustness under progressive image degradations and localization error."""

import argparse
import shutil
import tempfile
from pathlib import Path

import cv2
import numpy as np
import yaml

from rdsg_yolo.models.ultralytics_adapter import register_rdsg_modules
from rdsg_yolo.utils.degradations import DEGRADATION_PRESETS, apply_degradation
from rdsg_yolo.utils.metrics import compute_localization_errors


def load_yolo_gt_xyxy(label_path, img_w, img_h, target_cls=None):
    boxes = []
    if not label_path.exists():
        return np.zeros((0, 4), dtype=np.float64)
    for line in label_path.read_text(encoding="utf-8").splitlines():
        parts = line.strip().split()
        if len(parts) < 5:
            continue
        cls_id = int(float(parts[0]))
        if target_cls is not None and cls_id != target_cls:
            continue
        cx, cy, w, h = map(float, parts[1:5])
        x1 = (cx - 0.5 * w) * img_w
        y1 = (cy - 0.5 * h) * img_h
        x2 = (cx + 0.5 * w) * img_w
        y2 = (cy + 0.5 * h) * img_h
        boxes.append([x1, y1, x2, y2])
    return np.asarray(boxes, dtype=np.float64).reshape(-1, 4)


def evaluate_localization(model, images_dir, labels_dir, defect_cls=1, imgsz=640, conf=0.25):
    pred_boxes_all, pred_scores_all, gt_boxes_all = [], [], []
    img_paths = sorted(p for p in Path(images_dir).iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png"})
    for img_path in img_paths:
        img = cv2.imread(str(img_path))
        if img is None:
            continue
        h, w = img.shape[:2]
        gt = load_yolo_gt_xyxy(Path(labels_dir) / f"{img_path.stem}.txt", w, h, target_cls=defect_cls)
        res = model.predict(img, imgsz=imgsz, conf=conf, verbose=False)[0]
        if res.boxes is not None and len(res.boxes) > 0:
            cls_ids = res.boxes.cls.cpu().numpy().astype(int)
            mask = cls_ids == defect_cls
            p_box = res.boxes.xyxy.cpu().numpy()[mask]
            p_scr = res.boxes.conf.cpu().numpy()[mask]
        else:
            p_box = np.zeros((0, 4))
            p_scr = np.zeros((0,))
        pred_boxes_all.append(p_box)
        pred_scores_all.append(p_scr)
        gt_boxes_all.append(gt)
    return compute_localization_errors(pred_boxes_all, pred_scores_all, gt_boxes_all, conf_thr=conf, iou_thr=0.50)


def evaluate_degradations(model, data_yaml, split="test", imgsz=640, defect_cls=1):
    with open(data_yaml, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    root = Path(data_yaml).parent / cfg["path"]
    src_img_dir = root / cfg[split]
    src_lbl_dir = root / cfg[split].replace("images", "labels")

    print("\n=== Progressive Degradation Evaluation ===")
    for mode, levels in DEGRADATION_PRESETS.items():
        for level in levels:
            with tempfile.TemporaryDirectory() as tmp:
                tmp_root = Path(tmp)
                deg_imgs = tmp_root / "images" / split
                deg_lbls = tmp_root / "labels" / split
                deg_imgs.mkdir(parents=True, exist_ok=True)
                shutil.copytree(src_lbl_dir, deg_lbls)

                for img_path in sorted(src_img_dir.iterdir()):
                    if img_path.suffix.lower() not in {".jpg", ".jpeg", ".png"}:
                        continue
                    img = cv2.imread(str(img_path))
                    if img is None:
                        continue
                    deg = apply_degradation(img, mode, level)
                    cv2.imwrite(str(deg_imgs / img_path.name), deg)

                tmp_yaml = tmp_root / "deg.yaml"
                tmp_cfg = {
                    "path": str(tmp_root),
                    "train": f"images/{split}",
                    "val": f"images/{split}",
                    "test": f"images/{split}",
                    "names": cfg["names"],
                }
                tmp_yaml.write_text(yaml.safe_dump(tmp_cfg), encoding="utf-8")
                metrics = model.val(data=str(tmp_yaml), split=split, imgsz=imgsz, verbose=False)
                ap50_95 = float(metrics.box.maps[defect_cls]) * 100.0
                print(f"{mode:10s} | level={str(level):>4s} | defect AP50:95 = {ap50_95:.2f}%")


def main():
    parser = argparse.ArgumentParser(description="Evaluate robustness and localization errors.")
    parser.add_argument("--weights", required=True, help="Trained checkpoint path (.pt).")
    parser.add_argument("--data", default="data/cplid.yaml", help="Dataset YAML path.")
    parser.add_argument("--split", default="test", choices=["val", "test"])
    parser.add_argument("--defect-cls", type=int, default=1)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--skip-degradation", action="store_true")
    args = parser.parse_args()

    register_rdsg_modules()
    from ultralytics import YOLO

    model = YOLO(args.weights)
    with open(args.data, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    root = Path(args.data).parent / cfg["path"]
    src_img_dir = root / cfg[args.split]
    src_lbl_dir = root / cfg[args.split].replace("images", "labels")

    loc = evaluate_localization(model, src_img_dir, src_lbl_dir, defect_cls=args.defect_cls, imgsz=args.imgsz)
    print(
        f"Localization precision (matched={loc['num_matched']}): "
        f"Median e_c = {loc['median_ec_pct']:.2f}%, Median 1-IoU = {loc['median_1_minus_iou_pct']:.2f}%"
    )

    if not args.skip_degradation:
        evaluate_degradations(model, args.data, split=args.split, imgsz=args.imgsz, defect_cls=args.defect_cls)


if __name__ == "__main__":
    main()

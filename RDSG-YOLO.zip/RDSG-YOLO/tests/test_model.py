"""Unit tests verifying RDSG-YOLO forward/backward passes, shapes, and Alpha-CIoU."""

import torch

from rdsg_yolo.losses.alpha_ciou import alpha_ciou_loss
from rdsg_yolo.models.rdsg_model import RDSGYOLO
from rdsg_yolo.modules.rdkc import RDKC, C2fRDKC
from rdsg_yolo.modules.sgdf import SGDF


def test_rdkc_module():
    x = torch.randn(2, 64, 40, 40, requires_grad=True)
    mod = RDKC(channels=64, group_size=8, radii=(2, 4))
    y, diff = mod(x, return_diff=True)
    assert y.shape == (2, 64, 40, 40)
    assert diff.shape == (2, 32, 40, 40)
    (y.sum() + diff.sum()).backward()
    assert x.grad is not None and torch.isfinite(x.grad).all()


def test_sgdf_module():
    x_shallow = torch.randn(2, 128, 80, 80, requires_grad=True)
    y_deep = torch.randn(2, 256, 40, 40, requires_grad=True)
    diff_map = torch.randn(2, 32, 80, 80, requires_grad=True)
    sgdf = SGDF(c_shallow=128, c_deep=256, c_diff=32, c_compress=24)
    out = sgdf(x_shallow, y_deep, diff_map)
    assert out.shape == (2, 128, 80, 80)
    assert sgdf.last_gate.shape == (2, 1, 80, 80)
    assert (sgdf.last_gate > 0).all() and (sgdf.last_gate < 1).all()
    out.sum().backward()
    assert x_shallow.grad is not None and y_deep.grad is not None


def test_alpha_ciou_loss():
    gt = torch.tensor([[10.0, 10.0, 50.0, 50.0], [20.0, 30.0, 60.0, 70.0]])
    pred = torch.tensor([[12.0, 11.0, 48.0, 51.0], [25.0, 28.0, 58.0, 75.0]], requires_grad=True)
    for k in (1.0, 2.0, 3.0, 4.0):
        loss = alpha_ciou_loss(pred, gt, xywh=False, kappa=k)
        assert loss.shape == (2,)
        assert torch.isfinite(loss).all()
        assert (loss >= 0).all()
    loss_k3 = alpha_ciou_loss(pred, gt, xywh=False, kappa=3.0).mean()
    loss_k3.backward()
    assert pred.grad is not None and torch.isfinite(pred.grad).all()


def test_rdsg_yolo_full_network():
    model = RDSGYOLO(nc=2)
    x = torch.randn(1, 3, 640, 640)

    # Training mode
    model.train()
    preds, inter = model(x, return_intermediates=True)
    assert len(preds) == 3
    assert preds[0].shape == (1, 66, 80, 80)
    assert preds[1].shape == (1, 66, 40, 40)
    assert preds[2].shape == (1, 66, 20, 20)
    assert inter["E3"].shape == (1, 32, 80, 80)
    assert inter["E4"].shape == (1, 64, 40, 40)
    assert inter["a3"].shape == (1, 1, 80, 80)
    assert inter["a4"].shape == (1, 1, 40, 40)

    # Inference mode
    model.eval()
    with torch.no_grad():
        det, raw = model(x)
    assert det.shape == (1, 6, 8400)

    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"RDSG-YOLO (nc=2) parameters: {n_params:.2f} M")
    assert 9.5 <= n_params <= 11.5


if __name__ == "__main__":
    test_rdkc_module()
    test_sgdf_module()
    test_alpha_ciou_loss()
    test_rdsg_yolo_full_network()
    print("All unit tests passed.")

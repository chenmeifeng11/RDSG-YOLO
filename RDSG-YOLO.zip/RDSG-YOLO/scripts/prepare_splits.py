"""Group-aware 7:1:2 dataset splitter for CPLID and IDID (YOLO format)."""

import argparse
import os
import random
import re
import shutil
from collections import defaultdict
from pathlib import Path


IMG_EXTS = {".jpg", ".jpeg", ".png", ".bmp"}


def infer_group_key(stem):
    """Group derived/augmented variants with their source image stem."""
    # Strip trailing suffixes like _aug1, _rot, _flip, _copy, or _01
    return re.sub(r"(_aug\d*|_rot\d*|_flip\d*|_crop\d*|_copy\d*|_\d+)$", "", stem, flags=re.I)


def split_dataset(src_images, src_labels, out_dir, ratios=(0.7, 0.1, 0.2), seed=42):
    src_images = Path(src_images)
    src_labels = Path(src_labels)
    out_dir = Path(out_dir)

    groups = defaultdict(list)
    for img_path in sorted(src_images.iterdir()):
        if img_path.suffix.lower() in IMG_EXTS:
            groups[infer_group_key(img_path.stem)].append(img_path)

    group_keys = list(groups.keys())
    rng = random.Random(seed)
    rng.shuffle(group_keys)

    total_imgs = sum(len(v) for v in groups.values())
    n_train = int(round(total_imgs * ratios[0]))
    n_val = int(round(total_imgs * ratios[1]))

    splits = {"train": [], "val": [], "test": []}
    for key in group_keys:
        items = groups[key]
        if len(splits["train"]) < n_train:
            splits["train"].extend(items)
        elif len(splits["val"]) < n_val:
            splits["val"].extend(items)
        else:
            splits["test"].extend(items)

    for split_name, img_list in splits.items():
        img_out = out_dir / "images" / split_name
        lbl_out = out_dir / "labels" / split_name
        img_out.mkdir(parents=True, exist_ok=True)
        lbl_out.mkdir(parents=True, exist_ok=True)
        for img_path in img_list:
            shutil.copy2(img_path, img_out / img_path.name)
            lbl_src = src_labels / f"{img_path.stem}.txt"
            if lbl_src.exists():
                shutil.copy2(lbl_src, lbl_out / lbl_src.name)

    print(
        f"Split completed -> train: {len(splits['train'])}, "
        f"val: {len(splits['val'])}, test: {len(splits['test'])}"
    )


def main():
    parser = argparse.ArgumentParser(description="Group-aware 7:1:2 dataset splitter.")
    parser.add_argument("--images", required=True, help="Directory containing source images.")
    parser.add_argument("--labels", required=True, help="Directory containing YOLO .txt labels.")
    parser.add_argument("--out", required=True, help="Output dataset root directory.")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    split_dataset(args.images, args.labels, args.out, seed=args.seed)


if __name__ == "__main__":
    main()

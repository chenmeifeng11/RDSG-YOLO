# RDSG-YOLO

PyTorch implementation of **RDSG-YOLO** (*Reference-Difference Modeling and Structure-Guided Fusion for Insulator Defect Detection*), built upon YOLOv8s for UAV transmission line insulator inspection.

## Overview

RDSG-YOLO introduces three coordinated components on top of YOLOv8s:

- **Reference-Difference Kernel Convolution (`RDKC`)**: Dynamically modulates grouped $3\times 3$ local aggregation weights using center-to-neighborhood discrepancies sampled symmetrically across four orientations and two radii ($r \in \{2, 4\}$), integrated into backbone P3 and P4 `C2f-RDKC` stages (`rdsg_yolo/modules/rdkc.py`).
- **Structure-Guided Detail Fusion (`SGDF`)**: Incorporates multi-scale backbone difference maps ($E^3, E^4$) into a shared spatial protection gate that jointly regulates adaptive low-pass upsampling (ALPF) and local-similarity resampling offsets while enhancing shallow edges via AHPF (`rdsg_yolo/modules/sgdf.py`).
- **Alpha-CIoU Loss**: Applies power-law weighting ($\kappa = 3$) to overlap, center-distance, and aspect-ratio terms to sharpen bounding box localization on small defects (`rdsg_yolo/losses/alpha_ciou.py`).

## Repository Structure

```text
RDSG-YOLO/
├── configs/
│   └── rdsg_yolov8s.yaml          # Model architecture definition
├── data/
│   ├── cplid.yaml                 # CPLID dataset config (insulator, defect)
│   └── idid.yaml                  # IDID dataset config (good/broken/flashover-shell)
├── rdsg_yolo/
│   ├── modules/
│   │   ├── common.py              # Conv, Bottleneck, C2f, SPPF, Detect
│   │   ├── rdkc.py                # RDKC and C2fRDKC blocks
│   │   └── sgdf.py                # SGDF cross-scale fusion module
│   ├── losses/
│   │   └── alpha_ciou.py          # Alpha-CIoU loss and Ultralytics hook
│   ├── models/
│   │   ├── rdsg_model.py          # Standalone PyTorch RDSG-YOLO model
│   │   └── ultralytics_adapter.py # Ultralytics module registration
│   └── utils/
│       ├── degradations.py        # Blur, brightness, noise, JPEG transforms
│       └── metrics.py             # Median e_c and 1 - IoU localization metrics
├── scripts/
│   └── prepare_splits.py          # Group-aware 7:1:2 dataset split utility
├── tests/
│   └── test_model.py              # Forward/backward and loss unit tests
├── train.py                       # Training entrypoint
├── eval_robustness.py             # Localization error and degradation benchmark
└── predict_vis.py                 # Detection and Eigen-CAM heatmap visualization
```

## Installation

```bash
pip install -r requirements.txt
```

Verify the modules and full forward pass:

```bash
python tests/test_model.py
```

## Dataset Preparation

Organize CPLID and IDID annotations in standard YOLO format and split at a 7:1:2 ratio while keeping source images and derived copies in the same split:

```bash
python scripts/prepare_splits.py \
    --images /path/to/cplid/raw_images \
    --labels /path/to/cplid/raw_labels \
    --out datasets/cplid
```

Update `path:` in `data/cplid.yaml` and `data/idid.yaml` accordingly.

## Training

Train on CPLID (200 epochs, $640 \times 640$, batch size 16, SGD, Alpha-CIoU $\kappa=3$):

```bash
python train.py --cfg configs/rdsg_yolov8s.yaml --data data/cplid.yaml --epochs 200 --batch 16 --kappa 3.0
```

Train on IDID (set `nc: 3` in `configs/rdsg_yolov8s.yaml`):

```bash
python train.py --cfg configs/rdsg_yolov8s.yaml --data data/idid.yaml --epochs 200 --batch 16 --kappa 3.0
```

## Evaluation & Visualization

Run localization precision ($e_c$, $1 - \mathrm{IoU}$) and progressive degradation benchmarks:

```bash
python eval_robustness.py --weights runs/train/rdsg_yolo/weights/best.pt --data data/cplid.yaml
```

Generate detection overlays and activation heatmaps:

```bash
python predict_vis.py --weights runs/train/rdsg_yolo/weights/best.pt --source datasets/cplid/images/test --out runs/vis
```

## Results Summary

| Dataset | Model | mAP50 (%) | mAP50:95 (%) | Defect AP50:95 (%) | Params (M) | FLOPs (G) |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| CPLID | YOLOv8s | 95.4 | 76.8 | 69.7 | 11.1 | 28.4 |
| CPLID | **RDSG-YOLO** | **97.5** | **82.7** | **76.3** | **10.6** | **25.2** |
| IDID | YOLOv8s | 90.8 | 65.7 | 58.2 | 11.1 | 28.4 |
| IDID | **RDSG-YOLO** | **94.1** | **71.8** | **65.4** | **10.6** | **25.2** |

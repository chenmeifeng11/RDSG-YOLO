"""Training script for RDSG-YOLO on CPLID and IDID datasets."""

import argparse
from pathlib import Path

from rdsg_yolo.losses.alpha_ciou import patch_ultralytics_alpha_ciou
from rdsg_yolo.models.ultralytics_adapter import register_rdsg_modules


def parse_args():
    parser = argparse.ArgumentParser(description="Train RDSG-YOLO insulator defect detector.")
    parser.add_argument("--cfg", type=str, default="configs/rdsg_yolov8s.yaml", help="Model YAML path.")
    parser.add_argument("--data", type=str, default="data/cplid.yaml", help="Dataset YAML path.")
    parser.add_argument("--pretrained", type=str, default="yolov8s.pt", help="Pretrained checkpoint for weight transfer.")
    parser.add_argument("--epochs", type=int, default=200)
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--batch", type=int, default=16)
    parser.add_argument("--lr0", type=float, default=0.01)
    parser.add_argument("--momentum", type=float, default=0.937)
    parser.add_argument("--weight-decay", type=float, default=0.0005)
    parser.add_argument("--warmup-epochs", type=float, default=3.0)
    parser.add_argument("--kappa", type=float, default=3.0, help="Power exponent for Alpha-CIoU loss.")
    parser.add_argument("--device", type=str, default="0")
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--project", type=str, default="runs/train")
    parser.add_argument("--name", type=str, default="rdsg_yolo")
    parser.add_argument("--seed", type=int, default=42)
    return parser.parse_args()


def main():
    args = parse_args()

    # Register custom RDKC/SGDF modules and Alpha-CIoU loss into Ultralytics
    register_rdsg_modules()
    patch_ultralytics_alpha_ciou(kappa=args.kappa)

    from ultralytics import YOLO

    model = YOLO(args.cfg)
    if args.pretrained and Path(args.pretrained).exists():
        model.load(args.pretrained)

    model.train(
        data=args.data,
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        optimizer="SGD",
        lr0=args.lr0,
        momentum=args.momentum,
        weight_decay=args.weight_decay,
        warmup_epochs=args.warmup_epochs,
        cos_lr=True,
        device=args.device,
        workers=args.workers,
        project=args.project,
        name=args.name,
        seed=args.seed,
    )


if __name__ == "__main__":
    main()

"""Inference visualization for detection boxes and activation heatmaps."""

import argparse
from pathlib import Path

import cv2
import numpy as np
import torch

from rdsg_yolo.models.ultralytics_adapter import register_rdsg_modules


CLASS_COLORS = {
    "insulator": (220, 80, 30),
    "defect": (40, 40, 230),
    "good-shell": (180, 200, 40),
    "broken-shell": (25, 130, 240),
    "flashover-shell": (200, 40, 200),
}


def compute_eigen_cam(feat_tensor, target_hw):
    """Compute first principal component activation map from a 4D feature tensor."""
    feat = feat_tensor.detach().float()[0]  # (C, H, W)
    c, h, w = feat.shape
    mat = feat.reshape(c, -1)
    mat = mat - mat.mean(dim=1, keepdim=True)
    _, _, vh = torch.linalg.svd(mat, full_matrices=False)
    cam = vh[0].reshape(h, w).cpu().numpy()
    if cam.mean() < 0:
        cam = -cam
    cam = np.maximum(cam, 0.0)
    cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
    cam_resized = cv2.resize(cam, (target_hw[1], target_hw[0]), interpolation=cv2.INTER_CUBIC)
    return cam_resized


def overlay_heatmap(img_bgr, cam, alpha=0.45):
    heat = cv2.applyColorMap(np.uint8(255 * cam), cv2.COLORMAP_JET)
    return cv2.addWeighted(img_bgr, 1.0 - alpha, heat, alpha, 0)


def draw_detections(img_bgr, boxes, scores, cls_ids, names):
    canvas = img_bgr.copy()
    for box, score, cid in zip(boxes, scores, cls_ids):
        x1, y1, x2, y2 = map(int, box)
        label = names.get(int(cid), str(cid))
        color = CLASS_COLORS.get(label, (0, 200, 0))
        cv2.rectangle(canvas, (x1, y1), (x2, y2), color, 2)
        text = f"{label} {score:.2f}"
        (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
        ty = max(y1 - 4, th + 4)
        cv2.rectangle(canvas, (x1, ty - th - 4), (x1 + tw + 4, ty + 2), color, -1)
        cv2.putText(canvas, text, (x1 + 2, ty - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1, cv2.LINE_AA)
    return canvas


def main():
    parser = argparse.ArgumentParser(description="Visualize RDSG-YOLO predictions and heatmaps.")
    parser.add_argument("--weights", required=True, help="Trained checkpoint (.pt).")
    parser.add_argument("--source", required=True, help="Input image file or folder.")
    parser.add_argument("--out", default="runs/vis", help="Output directory.")
    parser.add_argument("--imgsz", type=int, default=640)
    parser.add_argument("--conf", type=float, default=0.25)
    parser.add_argument("--cam-layer", type=int, default=13, help="Neck feature layer index for Eigen-CAM.")
    args = parser.parse_args()

    register_rdsg_modules()
    from ultralytics import YOLO

    model = YOLO(args.weights)
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    captured = {}

    def _hook(_module, _inp, out):
        captured["feat"] = out

    target_layer = model.model.model[args.cam_layer]
    handle = target_layer.register_forward_hook(_hook)

    src = Path(args.source)
    img_paths = [src] if src.is_file() else sorted(p for p in src.iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png"})

    try:
        for img_path in img_paths:
            img = cv2.imread(str(img_path))
            if img is None:
                continue
            res = model.predict(img, imgsz=args.imgsz, conf=args.conf, verbose=False)[0]
            if res.boxes is not None and len(res.boxes) > 0:
                boxes = res.boxes.xyxy.cpu().numpy()
                scores = res.boxes.conf.cpu().numpy()
                cls_ids = res.boxes.cls.cpu().numpy().astype(int)
            else:
                boxes, scores, cls_ids = [], [], []

            det_img = draw_detections(img, boxes, scores, cls_ids, res.names)
            cv2.imwrite(str(out_dir / f"{img_path.stem}_det.jpg"), det_img)

            if "feat" in captured:
                cam = compute_eigen_cam(captured["feat"], img.shape[:2])
                cam_img = overlay_heatmap(img, cam)
                cam_det = draw_detections(cam_img, boxes, scores, cls_ids, res.names)
                cv2.imwrite(str(out_dir / f"{img_path.stem}_heatmap.jpg"), cam_det)
    finally:
        handle.remove()

    print(f"Saved visualizations to {out_dir}")


if __name__ == "__main__":
    main()
